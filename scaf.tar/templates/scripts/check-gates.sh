#!/usr/bin/env bash
#
# >>> usage
# 闸门检查器 —— 把「能机器判定的闸门」变成可执行检查。
#
#   scripts/check-gates.sh                 检查全仓库：tasks/ 下在飞的任务 + 全仓库的闸门 B
#                                          （tasks/_archive/ 跳过——见 tasks/README.md 的「归档」）
#   scripts/check-gates.sh --staged        检查索引内容（= 这次提交后的仓库状态；
#                                          任务目录只挑这次改动涉及的，pre-commit 钩子用）
#   scripts/check-gates.sh tasks/2026-08-04-add-login [...]
#
# 覆盖：
#   - 闸门 B：非 .md 文件里没有 [DEBUG- 残留（大小写不敏感；.md 是文档，会引用这个约定）。
#              排除 scripts/check-gates.sh 自身、node_modules/、二进制文件；
#              全量模式还排除 .gitignore 命中的本地文件（那是数据不是代码）
#   - plan.md：档位与类型已声明、目标 / 相关文件 / 验证命令非空、步骤表非空、
#              确认清单至少一条且全勾、
#              目标不能写「无」、预估 diff 范围三行不能全空、
#              测试 Seam 四行要么全填要么全空、
#              bug 任务的闸门 A 字段（含 ≥3 条排序假设）、bug-不可复现 必须声明 T3
#   - prd.md：验收标准非空且有条目；档位行填了就必须合法（不强制存在）
#   - journal.md：章节齐全（含雾区变化 / 一致性走查）、结束状态合法、验证结果有内容且不写「应该可以」、
#                 改动清单已填且没留模板占位符（src/... 或 <...>）、
#                 结束状态是 DONE / DONE_WITH_CONCERNS 时「主要提交」必须回填、
#                 「下次注意什么」每一条都写了去向（→ pitfalls / → 任务分级阈值 /
#                 → skills/<名> / 不沉淀）——只判有没有出口，不判内容质量
#   - NN-*.md（切片）：类型与状态取值合法、档位与优先级取值合法、演示与完成标准非空、
#                      文件范围与被谁挡已填、确认清单至少一条且全勾、状态 completed 时必须回填主要提交；
#                      决策条目则要求问题 / 结论 / 依据三字段非空
#   - review.md（裁决单）：任务档位是 T2 / T3、且任务**已经开工**时必须存在——plan.md /
#                          prd.md / 切片里**任何一处**声明了 T2/T3 就算，不依赖 plan.md 是否存在；
#                          （只提交了 prd.md 的计划阶段还不要求，那时候还没东西可审）
#                          章节齐全、固定点 / 审查者 / 给了它什么 / 轮次 / 结论都已填、
#                          审查者原文非空、逐条处理表非空、「审查者明确未判断的」不许留空
#   - 文档内相对引用：根目录 md、docs/、skills/、tasks/README.md 里用反引号或
#                      markdown 链接写下的相对路径必须存在（围栏代码块、带占位符的
#                      示例不算）。其他位置的 md 不查——第三方目录里的 README 是别人
#                      的文档，扫进来只会误报。tasks/ 其余部分是快照，断链属于历史。
#                      --staged 时文档内容取索引，但引用目标的存在性回工作区判
#                      （产物在 .gitignore 里，索引物化树里没有）。
#   - docs/adr/：任何 `ADR-NNNN` 引用都要有文件；`Superseded-By` 与 `Supersedes`
#                必须互指；写了 Superseded-By 就不能还是 `Status: accepted`
#   - 决策锚点（只提示，不影响退出码）：代码里的 `# 决策: ADR-NNNN` 注释，
#                指向不存在的 ADR 或没写目标时打一条 [!]。
#   - 架构：docs/architecture.md 的模块表 vs 实际模块目录（双向，模块根默认 src）。
#          表里全是宽声明（模块根本身或它的祖先）时，全量自查会提示一句：新增子目录不会被检查。
#          模块目录 = 模块根下**非空**的直接子目录（含还没 git add 的），点目录和被
#          .gitignore 命中的除外；空目录不算——git 不跟踪空目录，声明它反而会卡住提交。
#          模块根本身不查存在性（空目录进不了 git，clone 之后它会消失）
#
#   - 只改代码的提交（--staged）：如果这次动的文件出现在某个 T2/T3 任务 plan.md 的
#          「相关文件」里，而那个任务还没有非空的 review.md，拦下——这是「先提交代码、
#          后补审查」的入口。计划与裁决单都取索引版本。
#   - 任务目录里的文件名：只认 plan / prd / journal / review 与 NN-*.md（NN 1–2 位）；
#          三位以上数字开头的按笔记算（只提示），其余报错——否则整份文件静默免检。
#   - 规模底线（仅 --staged）：任务在模块根下**累计**改动的文件数 ≥ 4 时，必须有任务目录
#          声明 T2/T3。累计从 plan.md 进入历史的那次提交之前算起——按单次提交算的话，
#          把 T2 的活拆成两次提交就能溜过去。只查低报：T0 / T1 的档位声明不再等人确认，
#          这条是它的机械底线。只数模块根下的文件（文档、tasks/ 不计），阈值对齐 6 条信号。
#
# 不覆盖（判断性内容，留在 skills/ 里由人确认）：
#   双轴不合并、一次性脚本是否真删干净、命令是否真跑过、
#   档位**高报**（声明得比实际大），以及 6 条信号里的跨模块 / 动公开接口 /
#   行为变化 / 不可逆性四条——只有文件数一条两侧都查：≥ 4 必须在 T2/T3。
#   **任务是否真的收尾了**（journal.md 在提交之后才写，机器判断不了「这个任务结束了没有」）。
#
# 退出码：0 = 通过，1 = 有违规，2 = 用法错误。
# <<< usage

set -u

# 忽略 SIGPIPE。钩子是被 git 直接执行的：`git commit 2>&1 | head -1` 这类写法会让
# 读端提前退出，脚本写到第二行就吃 SIGPIPE，死在半路——实测 git 会**照常提交**
# （exit 0，闸门等于没跑）。把 SIGPIPE 改成写失败，脚本就能跑完并正常返回 1。
trap '' PIPE

violations=0

fail() { printf '  [x] %s\n' "$*"; violations=$((violations + 1)); }

# 提示，不是失败：计入输出，不影响退出码。用于「检查器当前覆盖不到」这类
# 需要人知道、但项目现状本身没错的情况。
note() { printf '  [!] %s\n' "$*"; }

# 用法说明就是文件头那段，用哨兵行圈出来 —— 写死行号会在加注释时漂移。
usage() {
    sed -n '/^# >>> usage$/,/^# <<< usage$/p' "${BASH_SOURCE[0]}" | sed '1d;$d' | sed 's/^# \{0,1\}//'
}

# ---------------------------------------------------------------- 各项检查
#
# 逐文件的判定逻辑整体在 check-gates.awk 里。为什么搬过去：本机起一个外部进程
# 约 27ms，而判定要做的字符串扫描（一个任务目录 40 来次、每次上百行）在 bash 里
# 约 13.7ms/120 行。两者叠加让全量自查变成分钟级；搬进 awk 后每个文件一次进程，
# 循环在 C 里跑。这里只负责挑文件、起进程、把违规行打出来并计数。

# 闸门 B：[DEBUG- 残留。
#   --staged：直接查索引（git grep --cached）。范围 = 这次提交后的仓库，和全量自查对齐；
#             不扫物化出来的临时树——那要先 checkout-index 把整棵树写到磁盘、再全扫一遍，
#             3000 文件 / 20MB 的仓库上 19s vs 0.67s。
#   全量：扫工作区（含未跟踪文件，那才是「全量」的意义）。
# **不用 -I**：`-I` 让 git 按「二进制」跳过文件，而「二进制」的判定包括一个 NUL 字节、
# 也包括 `.gitattributes` 里的 `-diff`——一行 `*.py -diff` 就能让所有 .py 免疫。
# 用 -a 强制当文本扫，多花的代价是二进制文件里可能命中同样的字节，所以改成
# **按后缀排除**（图片 / 压缩包 / 字体 / 快照），而不是让 git 猜。
#
# 变体也认：全角括号 `［DEBUG-］`、零宽字符插在中间（`[DEBU\u200bG-`）、
# 全角连字符。这些都是「看起来像但不是」，而闸门的价值就在于不给它留后门。
# 清理脚本里写着 `grep '[DEBUG-'` 不算残留——那行本身是找标记的工具
# （`xargs grep`、`if grep -q`、`git grep` 这些形态都认）。
check_gate_b() {
    local staged="$1" root="$2" hits
    local -a pat=(-e '\[DEBUG-' -E -e '［DEBUG[-－]' -e '\[DEBU.{1,6}G.{0,4}-')
    local -a skip=(
        ':(exclude,icase)*.md'
        ':(exclude)scripts/check-gates.sh' ':(exclude)scripts/check-gates.awk'
        ':(exclude)node_modules/*' ':(exclude)*/node_modules/*'
        ':(exclude,icase)*.png' ':(exclude,icase)*.jpg' ':(exclude,icase)*.jpeg'
        ':(exclude,icase)*.gif' ':(exclude,icase)*.ico' ':(exclude,icase)*.webp'
        ':(exclude,icase)*.pdf' ':(exclude,icase)*.zip' ':(exclude,icase)*.gz'
        ':(exclude,icase)*.svgz' ':(exclude,icase)*.woff' ':(exclude,icase)*.woff2'
        ':(exclude,icase)*.ttf' ':(exclude,icase)*.otf' ':(exclude,icase)*.eot'
        ':(exclude,icase)*.jar' ':(exclude,icase)*.war' ':(exclude,icase)*.class'
        ':(exclude,icase)*.pyc' ':(exclude,icase)*.so' ':(exclude,icase)*.dll'
        ':(exclude,icase)*.exe' ':(exclude,icase)*.bin' ':(exclude,icase)*.pdf'
        ':(exclude,icase)*.xlsx' ':(exclude,icase)*.docx' ':(exclude,icase)*.pptx'
        ':(exclude,icase)*.mp3' ':(exclude,icase)*.mp4' ':(exclude,icase)*.mov'
        ':(exclude,icase)*.wav' ':(exclude,icase)*.db' ':(exclude,icase)*.sqlite'
    )
    if [ "$staged" -eq 1 ]; then
        hits="$(git -C "$root" grep -a -i -n --cached "${pat[@]}" -- "${skip[@]}" 2>/dev/null || true)"
    else
        # 全量扫工作区。优先用 git：`--untracked --exclude-standard` = 已跟踪 +
        # 未跟踪但**不含 .gitignore 命中的**。那些是本地数据/缓存，不是要提交的
        # 代码，扫出 [DEBUG- 只会误报（全量自查常年红，人就开始无视它）。
        # 不在 git 仓库里时退回 find。
        if git -C "$root" rev-parse --git-dir >/dev/null 2>&1; then
            hits="$(git -C "$root" grep --untracked --exclude-standard -a -i -n "${pat[@]}" -- "${skip[@]}" 2>/dev/null || true)"
        else
            hits="$(find . -type f \
                ! -path './.git/*' ! -path '*/node_modules/*' \
                ! -iname '*.md' ! -path './scripts/check-gates.sh' ! -path './scripts/check-gates.awk' \
                ! -iname '*.png' ! -iname '*.jpg' ! -iname '*.jpeg' ! -iname '*.gif' \
                ! -iname '*.ico' ! -iname '*.webp' ! -iname '*.pdf' ! -iname '*.zip' \
                ! -iname '*.gz' ! -iname '*.svgz' ! -iname '*.woff' ! -iname '*.woff2' \
                ! -iname '*.ttf' ! -iname '*.otf' ! -iname '*.eot' \
                -exec grep -H -a -i -n -E '\[DEBUG-|［DEBUG[-－]|\[DEBU.{1,6}G.{0,4}-' {} + 2>/dev/null | sed 's|^\./||' || true)"
        fi
    fi
    # 一行本身在「找这个标记」（清理脚本、文档里的说明命令）不算残留。
    # 判据窄：整行以 grep / rg / ag / ack 开头，或含 `grep ... DEBUG-`——真调试埋点
    # 不会长这样。
    hits="$(printf '%s\n' "$hits" | grep -v -E '^[^:]*:[0-9]+:.*(grep|rg|ag|ack)[^:]*\[DEBUG' 2>/dev/null || true)"
    if [ -n "$hits" ]; then
        printf '%s\n' "$hits" | while IFS= read -r line; do
            printf '  [x] 闸门 B: %s —— 调试标记残留\n' "$line"
        done
        violations=$((violations + $(printf '%s\n' "$hits" | wc -l)))
    fi
}

# 把 awk 的输出原样打印，并把行数计进 violations。
# 不用 wc：$() 会吃掉尾换行，「行数 = 换行数 + 1」容易写错；违规行本来就少，
# 循环数一遍最省事，也不起进程。
emit_violations() {
    [ -n "$1" ] || return 0
    printf '%s\n' "$1"
    # 数**非空行**。调用方攒出来的字符串常常以换行结尾（`out="$out$line\n"`），
    # `<<<` 又会补一个换行，于是末尾多出一条空行被算成 1 项违规——
    # 屏幕上显示 4 条，收尾却写「闸门检查失败：5 项」。
    local n=0 l
    while IFS= read -r l; do [ -n "$l" ] && n=$((n + 1)); done <<< "$1"
    violations=$((violations + n))
}

# $1 = 判定种类（plan / prd / journal / slice / review），$2 = 文件
run_check() { emit_violations "$(awk -v kind="$1" -v fpath="$2" -f "$AWK_PROG" "$2")"; }

check_plan()    { run_check plan    "$1"; }
check_prd()     { run_check prd     "$1"; }
check_journal() { run_check journal "$1"; }
check_slice()   { run_check slice   "$1"; }

# 文档里的相对引用必须指向真实存在的文件。
#
# 为什么要有这条：`templates/AGENTS.md` 曾经指向 `WORKFLOW.md`（那个文件不随模板
# 分发，生成出来的项目里根本没有），三个角色提示词指向 `architecture.md` 里不存在
# 的小节。这类断链只能靠人读到才发现，而这套规则的价值恰恰在于「换个人/AI 接手时
# 顺着指针能找到东西」。
#
# 只查**活文档**：根目录的 md、`docs/`、`skills/`、`tasks/README.md`。
# `tasks/<任务>/` 是快照（任务结束后可能改名、删文件，那里的断链是历史不是缺陷），
# `tasks/_template/` 是**填空模板**（里面的示例路径本来就指向还不存在的东西）——
# 这两类跳过。注意 `tasks/README.md` 是活文档，不跳过：
# 约定、归档流程、闸门说明都写在那里，它的断链和 `docs/` 里的一样有害。
#
# 只查**像文件**的引用（最后一段带扩展名）。纯目录引用（`src/`、`docs/adr/`）不查：
# 空目录进不了 git，模板里也用它们做示意。
check_links() {
    local staged_mode="${1:-0}"
    local f ref line n=0 out="" total=0 cand b
    local -a files=() all=()

    # 只查**活文档**：仓库根的 md、`docs/`、`skills/`、`tasks/README.md`。
    #
    # 为什么按位置划而不是「扫所有 md」：第三方代码目录（`vendor/`、依赖包里
    # 带的 README）是**别人的文档**，它们的相对链接在这个仓库里必然对不上。把
    # 它们算进来，唯一出路是加一份项目级忽略清单——那会变成永久豁免通道，
    # 而「文档放在哪儿」本来就是明确的，按位置划不需要任何例外。
    is_doc() {
        case "$1" in
            tasks/README.md) return 0 ;;
            docs/*|skills/*) return 0 ;;
            */*) return 1 ;;
            *) return 0 ;;
        esac
    }

    # 文件清单用 git 拿，**不用 `find`**：`find` 会扫进 `.gitignore` 里的东西
    # （venv/、node_modules/、构建产物、编辑器缓存），那些目录里成千上万个
    # 第三方 README 全是别人的相对链接，跟这个项目没关系。实测一个 Python 项目
    # 因此多出 313 条假违规。不在 git 仓库里时才退回 find。
    #
    # --staged 时 **cwd 已经是索引物化出来的临时树**，所以文件取自那里（要查的是
    # 「即将提交的内容」），而不是工作区。
    if [ "$staged_mode" -eq 1 ]; then
        while IFS= read -r f; do
            f="${f#./}"
            is_doc "$f" || continue
            files+=("$f")
        done < <(find . -name '*.md' -type f 2>/dev/null | sort)
    elif git -C "$root" rev-parse --git-dir >/dev/null 2>&1; then
        # `core.quotepath=false`：默认会把非 ASCII 文件名转义成 `"\344\273..."`，
        # 那样 awk 打不开这些文件、直接报错退出，后面的文件一个都不会被扫到
        # （表现为「明明是断链却全绿」）。
        while IFS= read -r f; do
            is_doc "$f" || continue
            files+=("$f")
        done < <(git -C "$root" -c core.quotepath=false ls-files -co --exclude-standard -- '*.md' 2>/dev/null | sort)
    else
        while IFS= read -r f; do
            f="${f#./}"
            is_doc "$f" || continue
            files+=("$f")
        done < <(find . -name '*.md' -type f 2>/dev/null | sort)
    fi
    total="${#files[@]}"
    [ "$total" -gt 0 ] || return 0

    # 后缀索引用的文件清单也是「存在的文件」，--staged 时取两边的并集：
    # 只取物化树会漏掉被引用的产物，只取工作区会漏掉「已暂存、工作区还没建」的新文件。
    if [ "$staged_mode" -eq 1 ]; then
        # 只认**索引物化树**里的文件。并进工作区的未跟踪文件会让「已经从索引里删掉、
        # 工作区还留着」的目标被判存在——提交进去的树里它已经没了，链接是死的。
        # 产物（被 .gitignore 命中的）另有精确存在性豁免，不靠这份清单。
        while IFS= read -r f; do [ -n "$f" ] && all+=("${f#./}"); done \
            < <(find . -type f 2>/dev/null | sort)
    elif git -C "$root" rev-parse --git-dir >/dev/null 2>&1; then
        while IFS= read -r f; do all+=("$f"); done \
            < <(git -C "$root" -c core.quotepath=false ls-files -co --exclude-standard 2>/dev/null)
    else
        while IFS= read -r f; do all+=("${f#./}"); done \
            < <(find . -type f -not -path './.git/*' 2>/dev/null | sort)
    fi

    # 后缀索引：文档里常写简称（`static/app.js` 而真实路径是 `web/static/app.js`）。
    # 未命中的引用再看有没有哪个已跟踪文件以 `/<ref>` 结尾。
    # 只用于**放行**，不用于报错——报错仍然要求精确匹配。
    #
    # 这段放在 awk 里而不是 bash：bash 的关联数组（`local -A`）是 4.0 才有的，
    # 而 macOS 自带的 `/bin/sh` 是 bash 3.2（Ubuntu 上是 dash），生成出来的项目要能在这两种
    # 环境里跑起来——用关联数组会让它在 macOS 上直接报错退出、在 dash 上根本解析不过。
    # awk 的数组在 3.2 与 5.x 上都一样，而且一次进程就够（按 ref 逐个起 grep 会慢一个量级）。
    local idx_tmp refs_tmp
    idx_tmp="$(mktemp "${TMPDIR:-/tmp}/gates-idx.XXXXXX")"
    refs_tmp="$(mktemp "${TMPDIR:-/tmp}/gates-refs.XXXXXX")"
    printf '%s\n' ${all[@]+"${all[@]}"} > "$idx_tmp" 2>/dev/null || true

    # 第一遍：只挑出「精确路径和产物回退都不成立」的引用，交给 awk 判后缀。
    # 大多数引用在 `[ -e ]` 这一步就放行了，所以这一步通常写出零行。
    while IFS=$'\t' read -r f ref; do
        [ -n "$ref" ] || continue
        [ -e "$ref" ] && continue
        # 存在性回**工作区**再判一次。文档引用的常常是**产物**（`reports/*.md`、
        # 截图、生成的 json），它们落在 .gitignore 里、索引物化树里永远没有。
        # 只看物化树的话，同一个文档全量自查通过、钩子报 4 条——每次提交都被拦。
        # 只有**被 .gitignore 命中的产物**才允许回工作区放行。否则「索引里已删、
        # 工作区还在」的目标会被判存在——提交进去的树里它已经没了，链接是死的。
        if [ -n "${root_pwd:-}" ] && [ -e "$root_pwd/$ref" ] \
           && git -C "$root" check-ignore -q -- "$ref" 2>/dev/null; then
            continue
        fi
        printf '%s\t%s\n' "$f" "$ref"
    done < <(awk -v kind=links -f "$AWK_PROG" "${files[@]}" 2>/dev/null | sort -u) > "$refs_tmp"

    out="$(awk -F'\t' -v idx="$idx_tmp" '
        BEGIN {
            while ((getline l < idx) > 0) {
                if (l == "") continue
                b = l; sub(/.*\//, "", b)
                map[b] = (b in map) ? map[b] "\n" l : l
            }
        }
        {
            f = $1; ref = $2
            b = ref; sub(/.*\//, "", b)
            if (b in map) {
                nn = split(map[b], cand, "\n")
                for (i = 1; i <= nn; i++) {
                    c = cand[i]
                    if (c == ref) next
                    if (length(c) > length(ref) && substr(c, length(c) - length(ref)) == "/" ref) next
                }
            }
            printf "  [x] %s: 引用的 %s 不存在\n", f, ref
        }' "$refs_tmp")"
    if [ -n "$out" ]; then
        while IFS= read -r line; do [ -n "$line" ] && n=$((n + 1)); done <<< "$out"
    fi
    rm -f "$idx_tmp" "$refs_tmp"

    [ "$n" -gt 0 ] && printf '检查文档内的相对引用（%d 个文件）\n' "$total"
    emit_violations "$out"
}

# ADR 的引用与取代关系。见 check-gates.awk 的 adr_check。
check_adr() {
    local -a adrs=()
    local p
    for p in docs/adr/[0-9][0-9][0-9][0-9]-*.md; do
        [ -f "$p" ] && adrs+=("$p")
    done
    [ "${#adrs[@]}" -gt 0 ] || return 0
    emit_violations "$(awk -v kind=adr -f "$AWK_PROG" "${adrs[@]}" 2>/dev/null)"
}

# 代码里的决策锚点：`# 决策: ADR-0003`（`//` 同理）。
#
# 只做**提示**（note，不影响退出码），因为它三条判据的价值不对称：
# 「悬空锚点」该修；「这条 ADR 没有代码引用」不该报（「用 SQLite」这类决定本来
# 就不落在某一行代码上）；「锚点格式不对」也可能只是注释里的自然行文。
# 加进失败会让全量自查常年红，而常年红的结果就是没人再看它。
#
# 为什么值得有：`docs/architecture.md` 讲的是模块级，「这行为什么这么写」在代码里
# 没有出口。注释指向 ADR 是唯一的低成本路径，而注释最容易在重构中变成死链。
check_anchors() {
    local staged="$1" root="$2" hits=""
    local -a adrs=()
    local p id line rest num found
    for p in "$root"/docs/adr/[0-9][0-9][0-9][0-9]-*.md; do
        [ -f "$p" ] || continue
        id="${p##*/}"; adrs+=("${id:0:4}")
    done

    if [ "$staged" -eq 1 ]; then
        hits="$(git -C "$root" grep -I -n --cached -e '决策:' -- \
            ':(exclude)*.md' ':(exclude)*check-gates.sh' \
            ':(exclude)node_modules/*' ':(exclude)*/node_modules/*' 2>/dev/null || true)"
    elif git -C "$root" rev-parse --git-dir >/dev/null 2>&1; then
        hits="$(git -C "$root" grep --untracked --exclude-standard -I -n -e '决策:' -- \
            ':(exclude)*.md' ':(exclude)*check-gates.sh' \
            ':(exclude)node_modules/*' ':(exclude)*/node_modules/*' 2>/dev/null || true)"
    else
        hits="$( cd "$root" && find . -type f \
            ! -path './.git/*' ! -path '*/node_modules/*' \
            ! -name '*.md' ! -name 'check-gates.sh' \
            -exec grep -H -I -n '决策:' {} + 2>/dev/null | sed 's|^\./||' || true)"
    fi
    [ -n "$hits" ] || return 0

    while IFS= read -r line; do
        [ -n "$line" ] || continue
        case "$line" in
            *ADR-*) ;;
            *) note "锚点没写目标（应写成「决策: ADR-0001」）：$line"; continue ;;
        esac
        # 取 ADR- 之后的**前导数字**。不用 `substr`/`${v:0:4}`：
        # C locale 下那是按字节切，中文会被切坏（见 check-gates.awk 里同一类坑）。
        rest="${line#*ADR-}"
        num="${rest%%[!0-9]*}"
        case "$num" in
            [0-9][0-9][0-9][0-9]) ;;
            *) note "锚点的 ADR 编号不是 4 位数字：$line"; continue ;;
        esac
        if [ "${#adrs[@]}" -eq 0 ]; then
            note "锚点指向 ADR-$num，但 docs/adr/ 里还没有任何 ADR：$line"
            continue
        fi
        found=0
        for id in "${adrs[@]}"; do
            [ "$id" = "$num" ] && { found=1; break; }
        done
        [ "$found" -eq 1 ] || note "锚点指向 ADR-$num，但 docs/adr/ 里没有这个文件：$line"
    done <<< "$hits"
    return 0
}

# 任务是否已经「开工」——决定 T2/T3 的裁决单要不要。
# 判据是「任务目录里除了 prd.md / journal.md / review.md 还有没有别的文件」，
# 而不是「有没有 plan.md 或 NN-*.md」：后者能被改名绕过去（切片叫 `01_a.md`、
# 或把档位只写在 prd 里再补一份 DONE 的 journal，就整条免检了）。
# journal 宣告 DONE 也算开工——任务都收尾了，不能再拿「还没写计划」当挡箭牌。
task_has_started() {
    local d="$1" p st
    # 目录里除了这三份「任何任务都可能有的」文件之外还有别的东西 → 已经开工。
    # 文件、目录、非 .md 都算：`handoff.md` 和 `research/` 同样说明这个任务在推进。
    for p in "$d"/*; do
        [ -e "$p" ] || continue
        case "${p##*/}" in prd.md|journal.md|review.md) ;; *) return 0 ;; esac
    done
    # 裁决单本身在（哪怕还空着）也算开工：它出现就说明任务已经走到 3.8 了。
    # 少了这一条，`prd + journal(状态空) + 空 review.md` 会因为「没开工」跳过
    # 整份裁决单检查——空裁决单直接放行。
    [ -f "$d/review.md" ] && return 0
    # journal 记了结束状态 → 任务至少跑到收尾了。任何非空状态都算，
    # 不能只认 DONE：`DONE_WITH_CONCERNS` / `BLOCKED` 同样是「跑过了」。
    [ -f "$d/journal.md" ] || return 1
    st="$(awk -v kind=status -v fpath="$d/journal.md" -f "$AWK_PROG" "$d/journal.md")"
    [ -n "$st" ]
}

# review.md（裁决单）：只有 T2 / T3 需要。
# 「文件在不在」的判断留在 bash —— 文件都不在的时候，awk 没机会开口。
check_review() {
    local d="$1" f="$d/review.md"
    # 还没开工的任务（3.2 落 prd、3.3 定档位与计划、3.8 出裁决单）不要求裁决单，
    # 否则 T2/T3 任务连「先把 prd 提交一次」都做不到。
    task_has_started "$d" || return 0
    if [ ! -f "$f" ]; then
        fail "$f: 这个任务的档位是 T2/T3，但缺 review.md（这两档的审查必须由独立子 agent 做，见 docs/agents/任务分级.md）"
        return
    fi
    run_check review "$f"
}

# 本次提交的代码文件，是否属于某个「声明了 T2/T3 但还没裁决单」的在飞任务。
# 只认 plan.md 的「相关文件」——那是唯一把文件和任务连起来的机器可读字段。
check_review_by_scope() {
    local root="$1" d f rel hit
    local -a changed=()
    while IFS= read -r f; do
        [ -n "$f" ] && changed+=("$f")
    done < <(git -C "$root" -c core.quotepath=false diff --cached --name-only --diff-filter=ACMRD -- "${MODULE_ROOT%/}" 2>/dev/null)
    [ "${#changed[@]}" -gt 0 ] || return 0

    # plan.md / review.md 一律从**索引物化树**读（--staged 时 cwd 就是它）：
    # 读工作区的话，「未跟踪的空 review.md」或「未暂存地改掉计划的文件列表」
    # 都能让这条检查静默放行，而那正是它要防的东西。
    for d in tasks/*/; do
        d="${d%/}"
        case "$d" in tasks/_template|tasks/_archive) continue ;; esac
        [ -f "$d/plan.md" ] || continue
        task_is_high_tier "$d" || continue
        # 空裁决单不算有：`-s` 才认（一份 0 字节的 review.md 顶不了审查）
        [ -s "$d/review.md" ] && continue
        local -a rels=()
        while IFS= read -r rel; do
            [ -n "$rel" ] && rels+=("$rel")
        done < <(awk -v kind=related -f "$AWK_PROG" "$d/plan.md" 2>/dev/null)
        [ "${#rels[@]}" -gt 0 ] || continue
        hit=""
        for f in "${changed[@]}"; do
            for rel in "${rels[@]}"; do
                rel="${rel%/}"
                case "$f" in
                    "$rel"|"$rel"/*) hit="$f"; break ;;
                esac
            done
            [ -n "$hit" ] && break
        done
        [ -n "$hit" ] || continue
        fail "$d: 本次提交的 $hit 写在这个任务的「相关文件」里，而它是 T2/T3 且还没有 review.md —— 独立审查要在代码进主干之前做完（3.8）。如果这些改动不属于这个任务，把它们拆到自己的提交里"
    done
}

# 任务档位是否落在 T2/T3：plan.md / prd.md / 切片里任何一处声明了 T2/T3 就算。
# 不能只看 plan.md——档位也可能只写在 prd.md 或切片里；
# prd.md 的档位行也是同一个字段，只写在那里时同样得认。
task_is_high_tier() {
    local d="$1" f
    local files=()
    for f in "$d/plan.md" "$d/prd.md" "$d"/[0-9][-_]*.md "$d"/[0-9][0-9][-_]*.md; do
        [ -f "$f" ] && files+=("$f")
    done
    [ "${#files[@]}" -gt 0 ] || return 1
    [ "$(awk -v kind=tier -f "$AWK_PROG" "${files[@]}")" = "yes" ]
}

# 规模底线：声明的档位不能低于**数得出来**的改动量。
#
# 只查低报，不查高报：高报只是多一次审查，低报是拿「小改动」换免打扰——而 T0 / T1
# 的档位声明不再等人确认之后，低报就是「没人看」的唯一入口。
#
# 6 条信号里能机械化的只有文件数这一条：跨模块 / 动公开接口 / 行为变化 / 不可逆性
# 没有判据，仍然靠人看 diff。只数 $MODULE_ROOT 下的文件——量的是「改了多少代码」，
# 文档、tasks/ 不算。阈值对齐 docs/agents/任务分级.md 的 6 条信号表：文件数 ≥ 4 → T2 起。
#
# 只在 --staged 跑：全量自查没有「这次提交」这个基准。$3… = 本次改动涉及的任务目录。

# 数 $MODULE_ROOT 下从 $1（可为空 = 只看索引）到索引的改动文件数。
# -M：重命名算一次（和 `git diff --stat` 的文件数口径一致）；不认的话一次
# src/a → src/b 会被数成 2 个文件，小改动被误判成 T2。
count_code_changes() {
    local from="$1" root="$2" n=0 p range=()
    [ -n "$from" ] && range=("$from")
    while IFS= read -r p; do
        case "$p" in "${MODULE_ROOT%/}"/*) ;; *) continue ;; esac
        # 只数**代码**。模块根下也可能放文档、图片、快照；把它们算进「改了 4 个文件
        # 就是 T2」，会让「补 4 篇文档」被当成大改动。用法注释写的就是「文档不计」。
        case "${p##*.}" in
            md|markdown|txt|rst|png|jpg|jpeg|gif|svg|webp|ico|pdf|csv|json|yml|yaml) continue ;;
        esac
        n=$((n + 1))
    done < <(git -c core.quotepath=false -C "$root" diff --cached --name-only -M \
             --diff-filter=ACMRD ${range[@]+"${range[@]}"} -- "${MODULE_ROOT%/}" 2>/dev/null)
    printf '%s' "$n"
}

check_scale() {
    local staged="$1" root="$2"; shift 2
    [ "$staged" -eq 1 ] || return 0
    # 索引里没有代码改动 ⇒ 没有「这次提交」可判。
    # 不短路的话，下面按任务累计的分支算的是 base→索引；索引等于 HEAD 时
    # 那就是「该任务开始以来的全部改动」，历史 T0/T1 任务一律 ≥4 ⇒ 空跑必红。
    git -C "$root" diff --cached --quiet -- "${MODULE_ROOT%/}" 2>/dev/null && return 0
    local d base n max=0 max_dir="" who
    # 空树的 SHA：任务起点那个提交本身就是根提交时，`base^` 不存在，
    # 从空树算起才等同于「这个任务从零开始」。
    local empty_tree=4b825dc642cb6eb9a060e54bf8d69288fbee4904
    local cands=("$@")
    # 声明了 T2/T3 就免检——但**只有真写了计划的任务**才算数。
    # 否则 prd 里写一行 `T2`、再放一份空 journal，同一次提交 6 个 src 文件就全绿：
    # 没有 plan.md 就没有 3.4 的批准，也没有可审的对象，这个豁免没有任何依据。
    for d in ${cands[@]+"${cands[@]}"}; do
        if task_is_high_tier "$d"; then
            if [ -f "$d/plan.md" ]; then
                return 0
            fi
            fail "$d: 声明了 T2/T3，但没有 plan.md —— 没有计划就没有批准，也没有可审的对象。把计划落盘（3.3 / 3.5），或者这些改动不属于这个任务"
            return 0   # 已经报过，别再叠一条规模违规
        fi
    done
    if [ "${#cands[@]}" -eq 0 ]; then
        # 这次提交没碰任何任务目录——最常见的是「计划先提交、代码后提交」。
        # 这时不能只看本次索引：把 T2 的活拆成两次提交就能溜过去。
        # 但也不能退回「所有在飞任务」然后见到 T2 就让位——那样仓库里躺着一个
        # 没归档的 T2 任务，规模底线就永久失效。只累计**声明为 T0/T1** 的任务。
        #
        # 起点是「本次索引自己的改动数」：仓库里只有 T2/T3 在飞时（T0 不建目录，
        # 所以这是常态），没有任何 T0/T1 任务可以归属，这几处改动仍然要有人认领。
        max="$(count_code_changes "" "$root")"
        for d in "$root"/tasks/*/; do
            d="${d%/}"; d="${d#"$root"/}"
            # 模板目录不是任务：它的 plan.md 档位是 `T?`，会被当成 T0/T1，
            # 而它的起点是脚手架落地那次提交——于是「累计」把项目至今的全部
            # src 改动都算进一个假任务里，任何只改代码的提交都被拦。
            case "$d" in tasks/_template) continue ;; esac
            [ -f "$root/$d/plan.md" ] || continue
            task_is_high_tier "$d" && continue
            base="$(git -C "$root" log --diff-filter=A --format=%H -1 -- "$d/plan.md" 2>/dev/null)"
            [ -n "$base" ] || continue
            base="$(git -C "$root" rev-parse -q --verify "$base^" 2>/dev/null || printf '%s' "$empty_tree")"
            n="$(count_code_changes "$base" "$root")"
            if [ "$n" -gt "$max" ]; then max="$n"; max_dir="$d"; fi
        done
        n="$max"
    else
        # 按**任务**累计，不按单次提交：从 plan.md 进入历史的那次提交之前算起。
        # 只量本次 diff 的话，把 T2 的活拆成两次提交就能溜过去——而「一个任务
        # 对应一个主要提交」本来就是 tasks/README.md 的约定。
        for d in ${cands[@]+"${cands[@]}"}; do
            base="$(git -C "$root" log --diff-filter=A --format=%H -1 -- "$d/plan.md" 2>/dev/null)"
            if [ -n "$base" ]; then
                base="$(git -C "$root" rev-parse -q --verify "$base^" 2>/dev/null || printf '%s' "$empty_tree")"
            fi
            n="$(count_code_changes "$base" "$root")"
            if [ "$n" -gt "$max" ]; then max="$n"; max_dir="$d"; fi
        done
        n="$max"
    fi
    [ "$n" -ge 4 ] || return 0
    # 报出是哪个任务超的：仓库里几十个 T0/T1 任务时，只说「这个任务」等于让人手算。
    # 没有可归属的任务（改动全在本次索引里）时主语换成「本次改动」，别再拼出
    # 「任务 （本次改动） 的…」这种半句话。
    if [ -n "$max_dir" ]; then
        who="任务 $max_dir"
    else
        who="本次改动"
    fi
    fail "$who 的代码改动累计 $n 个 $MODULE_ROOT 下的文件，但没有声明 T2/T3 —— 按 docs/agents/任务分级.md 的 6 条信号，文件数 ≥ 4 就是 T2。把 plan.md 的档位升到 T2 并补 review.md（3.4 批准 + 3.8 独立审查）；如果这些文件分属别的任务，说明这个提交混了多个任务，按「一个任务一个提交」拆开"
}

# ---------------------------------------------------------------- 架构

# 模块根：这个目录的直接子目录就是模块。项目布局不同时改这里，
# 或用环境变量覆盖：MODULE_ROOT=app bash scripts/check-gates.sh
MODULE_ROOT="${MODULE_ROOT:-src}"

# `## 模块划分` 表第 2 列声明的路径，去掉反引号与尾斜杠。
# 表本身的解析在 check-gates.awk 的 kind=modules 里——和逐文件检查共用同一套
# 注释剥离，省得两处对「注释算不算内容」有不同看法。
declared_module_paths() {
    awk -v kind=modules -f "$AWK_PROG" "$1" | sort -u
}

# 目录与路径的**存在性**以工作区为准，不取索引：索引里没有「空目录」这个概念，
# 而 src/ 恰恰是空的 —— 只看索引会在首次提交时误报「src 不存在」。
# 表的内容取索引版本（见 check_architecture）。
# 模块根下的子目录。在**哪棵树**里找，由调用方决定：全量模式 cd 在仓库里，
# 暂存模式 cd 在索引物化出的临时树里 —— 各自看各自该看的那份内容。
# 只算**非空**目录：
#   - 空目录 git 根本不跟踪，声明它会被规则 1 判「声明了却不存在」，
#     不声明又违反规则 2 —— 两头堵死。它本来也不是模块。
# 点目录和被 .gitignore 命中的不算：src/.cache 既进不了提交，也不该进模块表。
arch_module_dirs() {
    local staged="$1" root="$2" d files
    while IFS= read -r d; do
        [ -n "$d" ] || continue
        case "${d##*/}" in .*) continue ;; esac        # 点目录不是模块
        # 只算「clone 之后还会在」的目录：里面有 git 跟踪的、或者会被跟踪的
        # （未跟踪且没被 .gitignore 命中）文件。三类目录不算，它们声明不了：
        #   - 空目录：git 不跟踪空目录
        #   - 只装着被 ignore 的文件的目录（`src/logs/` 下只有 *.log）
        #   - 只含空子目录的目录
        # 声明它们会在 clone 里变成「声明了却不存在」，不声明又违反规则 2，两头堵死。
        # 目录列表来自 cwd（暂存模式是索引物化出的临时树），但「有没有内容」必须问
        # 真正的仓库：临时树不是 git 仓库，在那儿跑 git 会失败并静默返回空。
        if [ "$staged" -eq 1 ]; then
            files="$(git -C "$root" -c core.quotepath=false ls-files -c -- "$d" 2>/dev/null | head -n 1)"
        else
            files="$(git -C "$root" -c core.quotepath=false ls-files -co --exclude-standard -- "$d" 2>/dev/null | head -n 1)"
        fi
        [ -n "$files" ] && printf '%s\n' "$d"
    done < <(
        [ -d "$MODULE_ROOT" ] || exit 0
        find "$MODULE_ROOT" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort -u
    )
}

arch_path_exists() { [ -e "$1/$2" ]; }

# 模块表 vs 实际目录，双向比对。防两件事：模块被改名 / 移动 / 删除而表没跟着改，
# 以及新加了模块目录却没进表。
#
# 覆盖语义：声明的路径覆盖它自己、它的祖先和它的后代。所以表里写 `src` 等于
# 「整个 src 当一个模块」，子目录不再逐个要求；写具体子目录，则新加的子目录必须进表。
check_architecture() {
    local staged="$1" root="$2"
    local doc="docs/architecture.md"

    if [ "$staged" -eq 1 ]; then
        # 暂存模式下 cwd 是索引物化出的整棵树，表进了索引就是索引版本
        # （所以「暂存了坏表」会被拦住）。没进索引（还没 commit 过、又没 add 过它）
        # 才退回工作区版本——否则会把「文件明明在仓库里」报成不存在。
        doc="$check_tree_tmp/docs/architecture.md"
        if [ ! -f "$doc" ]; then
            mkdir -p "$check_tree_tmp/docs"
            cp "$root/docs/architecture.md" "$doc" 2>/dev/null || rm -f "$doc"
        fi
    fi

    if [ ! -f "$doc" ]; then
        fail "docs/architecture.md 不存在"
        return
    fi

    local declared
    declared="$(declared_module_paths "$doc")"
    if [ -z "$declared" ]; then
        fail "docs/architecture.md 的「## 模块划分」表里没有声明任何模块"
        return
    fi

    # 模块根不存在 ⇒ 架构比对和规模底线都在空转，「闸门通过」是假的。
    # 不能 fail：`src/` 是空目录，git 不跟踪空目录，刚 clone 的仓库里它就不在。
    # 但必须说出来 —— 代码不在 src/ 的项目（`uv init`、`create-next-app` 的 app/）
    # 会得到一个全绿的闸门，而什么都没查。
    if [ ! -d "$root/$MODULE_ROOT" ]; then
        note "模块根 \`$MODULE_ROOT\` 不存在：模块表比对与规模底线都不生效。代码不在这个目录时，用 \`MODULE_ROOT=<真实目录> bash scripts/check-gates.sh\`，或改脚本里 MODULE_ROOT 的默认值。"
    fi

    # 路径归一化：`./src/a`、`.\src\a`、`src//a`、`src/a/` 都是同一个目录。
    # 不归一的话，表里换一种合法写法就会被判成「表里没有它」——规则 1 用 -e 认它，
    # 规则 2 用字符串比却不认，同一份表出现两种结论。
    # Windows（MSYS/Cygwin）的文件系统大小写不敏感，`src/Auth` 与 `src/auth` 是同一
    # 个目录，比较时折成小写；Linux/macOS 上大小写不同就是两个目录，不能折。
    local fold=0
    case "$(uname -s 2>/dev/null)" in MINGW*|MSYS*|CYGWIN*) fold=1 ;; esac
    norm_path() {
        local v="$1"
        v="${v//\\//}"                       # 反斜杠 → 斜杠
        while [ "${v#./}" != "$v" ]; do v="${v#./}"; done
        # 连续斜杠压成一个。注意是压成 `/`，不是删掉——删掉会把 `src//a` 变成
        # `srca`，成了另一个路径（这条曾经是真实 bug）。
        v="$(printf '%s' "$v" | sed 's|//*|/|g')"
        # 中间的 `./` 段（`src/./a`）
        v="$(printf '%s' "$v" | sed 's|/\./|/|g')"
        v="${v%/}"
        [ "$fold" -eq 1 ] && v="$(printf '%s' "$v" | tr 'A-Z' 'a-z')"
        printf '%s' "$v"
    }
    local -a decl_norm=()
    local pn
    while IFS= read -r p; do
        [ -n "$p" ] || continue
        pn="$(norm_path "$p")"
        [ -n "$pn" ] || continue
        decl_norm+=("$pn")
    done <<< "$declared"

    # 规则 1：声明的路径必须真实存在。
    # 例外：模块根本身（及它的祖先）不查 —— `src/` 是空目录，git 不跟踪空目录，
    # clone 之后它就不在了，而 Phase 2 的模块表正要求写宽路径 `src`。
    # 这条要是报错，新 clone 的仓库会卡到「所有提交都过不去」。
    local mr_norm
    mr_norm="$(norm_path "$MODULE_ROOT")"
    for p in ${decl_norm[@]+"${decl_norm[@]}"}; do
        [ -n "$p" ] || continue
        case "$mr_norm/" in "$p/"*) continue ;; esac
        arch_path_exists "$root" "$p" \
            || fail "docs/architecture.md 声明了模块「$p」，但它不存在"
    done

    # 规则 2：$MODULE_ROOT 下的直接子目录必须被某个声明覆盖
    local d covered q dn
    while IFS= read -r d; do
        [ -n "$d" ] || continue
        covered=0
        dn="$(norm_path "$d")"
        for q in ${decl_norm[@]+"${decl_norm[@]}"}; do
            case "$q/" in "$dn/"*) covered=1; break ;; esac
            case "$dn/" in "$q/"*) covered=1; break ;; esac
        done
        [ "$covered" -eq 1 ] \
            || fail "「$d」是 $MODULE_ROOT 下的模块目录，但 docs/architecture.md 的模块表里没有它"
    done < <(arch_module_dirs "$staged" "$root")

    # 提示（不是失败）：表里全是宽声明时，规则 2 永远不触发——新增模块目录不会被检查。
    # 只在全量自查时报；--staged 每次提交都跑，不适合反复提示。
    if [ "$staged" -eq 0 ]; then
        local specific=0
        while IFS= read -r p; do
            [ -n "$p" ] || continue
            p="${p%/}"          # `src/` 与 `src` 是同一种声明，先去掉尾斜杠
            case "$p" in
                "$MODULE_ROOT"/*) specific=1; break ;;
            esac
        done <<< "$declared"
        if [ "$specific" -eq 0 ]; then
            note "模块表只声明了宽路径（$MODULE_ROOT 本身或它的祖先），所以「$MODULE_ROOT 下新增子目录」这条检查当前不会触发。"
            note "项目长大之后，把表拆成具体子模块（如 $MODULE_ROOT/auth、$MODULE_ROOT/billing），让这条检查生效。"
        fi
    fi
}

# ---------------------------------------------------------------- 主流程

main() {
    local staged=0
    local task_args=()

    while [ "$#" -gt 0 ]; do
        case "$1" in
            --staged) staged=1 ;;
            -h|--help) usage; exit 0 ;;
            --) shift; break ;;
            -*) printf '未知选项: %s\n' "$1" >&2; exit 2 ;;
            *) task_args+=("$1") ;;
        esac
        shift
    done
    while [ "$#" -gt 0 ]; do task_args+=("$1"); shift; done

    local root
    # 调用时的 cwd：命令行里点名的任务目录按它解析（脚本随后会 cd 到仓库根/临时树）。
    invoke_pwd="$(pwd)"
    root="$(git rev-parse --show-toplevel 2>/dev/null || true)"
    [ -n "$root" ] || root="$(cd "$(dirname "$0")/.." && pwd)"
    # git 给的是 `D:/…`，bash 的 pwd 给的是 `/d/…` —— 两种写法不能直接比前缀。
    # 统一成 bash 的写法，下面把点名路径折成仓库相对路径时才不会漏。
    root_pwd="$(cd "$root" && pwd)"

    # 判定逻辑在 check-gates.awk，与本脚本同目录。脚本自身始终取工作区版本
    # （钩子调的也是工作区的 scripts/check-gates.sh），所以要在 cd 进临时树之前解析。
    AWK_PROG="$(cd "$(dirname "$0")" && pwd)/check-gates.awk"
    if [ ! -f "$AWK_PROG" ]; then
        printf '找不到 %s —— 它与 check-gates.sh 必须放在一起\n' "$AWK_PROG" >&2
        exit 2
    fi

    if [ "$staged" -eq 1 ]; then
        # 内容必须取自索引。只拿 git diff --cached 的文件名、却读工作区，会在
        # 「已暂存的是坏内容、工作区已修好」时放行，反方向则误拦一次合法提交。
        #
        # 物化的是**整个索引**，不是这次改动的那几个文件：检查会问「某个这次没动的
        # 文件在不在」（T2/T3 的 review.md、plan.md 里的档位都是这种），只物化 diff
        # 会让这类问题一律得到「文件不存在」——该拦的漏掉，不该拦的拦住。
        #
        # 凡是**列文件名**的 git 调用都带 -c core.quotepath=false：这个设置存在
        # .git/config 里，不随 clone 走。少了它，clone 回来的仓库里中文名路径会被
        # 引号+八进制转义，case 匹配失配 —— 那些文件会静默逃过全部检查。
        #
        # 临时目录用全局变量：EXIT trap 在 main 返回之后才执行，那时 local 已经出作用域，
        # set -u 会把 "$check_tree_tmp" 当成未绑定变量，trap 失败 → 脚本整体非 0。
        check_tree_tmp="$(mktemp -d "${TMPDIR:-/tmp}/gates-tree.XXXXXX")"
        trap 'rm -rf "$check_tree_tmp"' EXIT
        # 物化失败必须硬停：否则会在一个空临时树里继续跑，每个任务目录都报
        # 「缺 plan.md / journal.md」——一堆假违规比一句报错难查得多。
        if ! git -C "$root" checkout-index -a --prefix="$check_tree_tmp/" 2>/dev/null; then
            printf '  [x] 无法把 git 索引物化到临时目录（checkout-index 失败），--staged 中止\n' >&2
            exit 2
        fi
        cd "$check_tree_tmp" || exit 2
    else
        cd "$root" || exit 2
    fi

    # 闸门 B：残留扫描。--staged 查索引，全量查工作区
    check_gate_b "$staged" "$root"

    # 架构：模块表 vs 实际目录。仓库状态不变量，两种模式都跑
    check_architecture "$staged" "$root"

    # 文档内相对引用 + ADR 互链：都是「仓库状态」不变量，和具体任务无关
    if [ "$staged" -eq 0 ]; then
        local hp
        hp="$(git -C "$root" config core.hooksPath 2>/dev/null)"
        if [ "$hp" != ".githooks" ]; then
            note "core.hooksPath 不是 .githooks（当前：${hp:-未设置}）：提交前闸门不会自动执行。跑一次 \`git config core.hooksPath .githooks\`。"
        fi
    fi

    check_links "$staged"
    check_adr
    # 代码里的 `决策: ADR-NNNN` 锚点：只提示，不影响退出码
    check_anchors "$staged" "$root"

    # 要检查哪些任务目录
    local dirs=()
    local d p rest st p1 p2 np
    if [ "${#task_args[@]}" -gt 0 ]; then
        # 参数按**调用时**的 cwd 解析。脚本后面会 cd 到仓库根，
        # 从子目录用相对路径点名（`cd docs && ../scripts/check-gates.sh ../tasks/x`）
        # 就会找不到——那时 ../tasks/x 是相对 docs 的，不是相对仓库根。
        local a rel
        for a in "${task_args[@]}"; do
            case "$a" in
                /*|[A-Za-z]:[/\\]*) rel="$a" ;;
                *) rel="$invoke_pwd/$a" ;;
            esac
            case "$rel" in
                "$root_pwd"/*) rel="${rel#"$root_pwd"/}" ;;
            esac
            case "$rel" in
                tasks/_template|tasks/_template/)
                    printf '%s\n' "跳过 $rel（模板，不是任务）"
                    continue ;;
            esac
            if [ -d "$rel" ]; then dirs+=("$rel"); else fail "找不到任务目录: $a"; fi
        done
    elif [ "$staged" -eq 1 ]; then
        # D 也要算：只删 review.md 的那次提交同样得查那个任务目录，
        # 不然「T2/T3 必须有 review.md」在删除路径上是空的。
        while IFS=$'\t' read -r st p1 p2; do
            # 重命名/复制时第二列是目标路径；其余状态只有一列。
            case "$st" in R*|C*) np="$p2" ;; *) np="$p1" ;; esac
            [ -n "${np:-}" ] || continue

            # 拍平检测要放在重命名豁免**之前**：`git mv tasks/x tasks/_archive`
            # 在 _archive 不存在时正是 R100——跳过 R100 就会把这种归档方式放过去，
            # 而那层的文件从此不在任何全量检查的覆盖里。
            #
            # 注意 case 的 `*` 会跨 `/`：不能写 `tasks/_archive/*.md`——那会把
            # `tasks/_archive/<任务>/journal.md` 也匹配上，正常归档全被判成拍平。
            case "$np" in
                tasks/_archive/*)
                    rest="${np#tasks/_archive/}"
                    case "$rest" in
                        */*) : ;;   # 正常归档：<任务>/<文件>
                        *)
                            fail "$np: tasks/_archive/ 顶层不该有文件——归档要 'mkdir -p tasks/_archive' 之后再 git mv，见 tasks/README.md 的「归档」"
                            continue ;;
                    esac ;;
            esac

            # 纯重命名 / 纯复制（内容一字未变）不算改动。归档就是把任务目录挪进
            # tasks/_archive/，文件本身没变；按内容查会把「归档」这个被推荐的动作
            # 本身判红（旧格式的任务目录一归档就 60 条违规）。
            case "$st" in R100|C100) continue ;; esac

            case "$np" in
                # 归档过的任务在 tasks/_archive/<任务>/ 下，比在飞的深一层。
                # 改到它照样要查——「跳过」只针对全量自查，不是免检。
                tasks/_archive/*/*)
                    rest="${np#tasks/_archive/}"
                    dirs+=("tasks/_archive/${rest%%/*}") ;;
                tasks/*/*)
                    rest="${np#tasks/}"
                    d="tasks/${rest%%/*}"
                    case "$d" in tasks/_template) continue ;; esac
                    dirs+=("$d") ;;
            esac
        done < <(git -c core.quotepath=false -C "$root" diff --cached --name-status -M --diff-filter=ACMRD 2>/dev/null)
    else
        # `tasks/_archive/` 里**直接躺着 .md 文件**说明归档方式用错了：
        # `git mv tasks/x tasks/_archive/` 在 _archive 不存在时会把任务目录改名成
        # `_archive`，文件被拍平到这一层。拍平之后全量自查会把它整个跳过——
        # 那些文件从此不在任何全量检查的覆盖里（--staged 碰到才会查）。
        for f in tasks/_archive/*.md; do
            [ -f "$f" ] || continue
            fail "$f: tasks/_archive/ 顶层不该有文件——归档要 'mkdir -p tasks/_archive' 之后再 git mv，见 tasks/README.md 的「归档」"
            break
        done
        for d in tasks/*/; do
            [ -d "$d" ] || continue
            # _template 是模板；_archive 是已完成并归档的（tasks/ 只放在飞的）。
            # 归档目录不是一个任务目录，它的子目录也不在 tasks/*/ 这一层——
            # 但留着这句，免得以后有人往 _archive/ 顶层放文件时被当成任务。
            case "$d" in tasks/_template/|tasks/_archive/) continue ;; esac
            dirs+=("${d%/}")
        done
    fi

    # 规模底线：只在 --staged 有意义（要有「这次提交」这个基准）
    check_scale "$staged" "$root" ${dirs[@]+"${dirs[@]}"}

    # 计划里的文件已被提交、但这个 T2/T3 任务还没有裁决单 —— 说明「先提交代码、
    # 后补审查」。归属靠 plan.md 的「相关文件」：它机器可读，而「哪次提交属于哪个
    # 任务」看不出来。多次提交里只要有一次命中，审查就来不及了。
    if [ "$staged" -eq 1 ]; then
        check_review_by_scope "$root"
    fi

    # 去重后逐个检查
    local seen="|"
    for d in ${dirs[@]+"${dirs[@]}"}; do
        case "$seen" in *"|$d|"*) continue ;; esac
        seen="$seen$d|"
        local any=0
        if [ -f "$d/plan.md" ]; then
            printf '%s\n' "检查 $d/plan.md"
            check_plan "$d/plan.md"
            any=1
        fi
        if [ -f "$d/prd.md" ]; then
            printf '%s\n' "检查 $d/prd.md"
            check_prd "$d/prd.md"
            any=1
        fi
        # T2 / T3 的审查必须换人做，产出裁决单（见 docs/agents/任务分级.md）。
        # 独立于 plan.md 是否存在——档位也可能只写在切片里。
        if task_is_high_tier "$d"; then
            check_review "$d"
            any=1
        fi
        if [ -f "$d/journal.md" ]; then
            printf '%s\n' "检查 $d/journal.md"
            check_journal "$d/journal.md"
            any=1
        fi
        # 切片 / 决策条目：NN-*.md，NN 是 1–2 位数字（见 tasks/README.md）。
        # 同时认下划线分隔（`01_a.md`）——只认短横线的话，改个名字就整条免检了。
        # 两位数字的上限把 `2026-10-31-调研.md` 这类笔记排除在外（那是笔记不是切片）。
        local s
        for s in "$d"/[0-9][-_]*.md "$d"/[0-9][0-9][-_]*.md; do
            [ -f "$s" ] || continue
            printf '%s\n' "检查 $s"
            check_slice "$s"
            any=1
        done
        # 文件名不在约定里时，上面所有分支都不会碰它，那个文件于是整条免检。
        # **无条件**扫（有 plan.md 时也一样）：`100-x.md` 混进一个正常任务目录，
        # 同样会被静默跳过。三位以上数字开头的是笔记（tasks/README.md 的约定），只提示。
        local u
        for u in "$d"/*.[mM][dD]; do
            [ -f "$u" ] || continue
            case "${u##*/}" in
                plan.md|prd.md|journal.md|review.md) continue ;;
                [0-9][0-9][-_]*.md|[0-9][-_]*.md) continue ;;
                [0-9][0-9][0-9]*) note "$u: 三位以上数字开头，按 tasks/README.md 的约定当笔记处理，不检查"; continue ;;
            esac
            fail "$u: 不认识的任务文件名 —— 任务目录里只可能是 plan.md / prd.md / journal.md / review.md，或 NN-*.md 切片（NN 是 1–2 位数字）"
            any=1
        done
        [ "$any" -eq 1 ] || printf '%s\n' "跳过 $d（还没有 plan.md / journal.md / NN-*.md）"
    done

    if [ "$violations" -eq 0 ]; then
        printf '闸门检查通过。\n'
        return 0
    fi
    printf '闸门检查失败：%d 项。\n' "$violations"
    return 1
}

main "$@"
