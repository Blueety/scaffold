# 易错点

> 记录反复出现的问题和坑。Agent 修改相关模块前必须先读。

## 通用

- （暂无）

## 模块: src/

<!-- 按模块补充易错点 -->
<!--
格式:
### 模块名
- 修改 A 时必须同步 B
- 某测试需要特定环境变量
- 某函数有隐式依赖
-->

## 环境相关

<!-- 记录 Node/Python/系统/编码等环境坑。格式：

### 问题一句话
- **现象**: 报错原文或异常表现
- **原因**: 为什么会这样
- **解决**: 能直接粘贴执行的命令。环境坑的解法就是一条命令，
  不给命令等于没记——下次还得重新查一遍。

例：

### Windows 上 npm script 里的单引号不生效
- **现象**: `npm run x` 在 Git Bash 里正常，在 PowerShell 里报语法错误
- **原因**: npm 在 Windows 上默认用 cmd.exe 执行 script，不认单引号
- **解决**: 把 script 里的单引号换成转义双引号，或写进独立的 .js 脚本
-->

- （暂无）

### Windows 上 `bash scripts/check-gates.sh` 根本没跑到脚本

- **现象**: 输出一串 `?????`，退出码 1——看着像「闸门有违规」，其实命令没执行到脚本
- **原因**: PATH 里排第一的 `bash.exe` 是 `C:\Windows\System32\bash.exe`（WSL 的桩），它不认识 Windows 路径
- **解决**: 在 Git Bash 里跑 `bash scripts/check-gates.sh`；或在 PowerShell 里用 Git 自带的 sh：`sh scripts/check-gates.sh`（**只在 sh 真是 bash 时**——Ubuntu 的 `/bin/sh` 是 dash，这个脚本用不了）

### PowerShell 里 `git commit` 的闸门提示是乱码

- **现象**: 提交被钩子拦下，但 `check-gates.sh` 的中文提示显示成 `闂搁棬妫€鏌ュけ璐ワ細`，看不出挂了哪一条
- **原因**: 钩子里的脚本按 UTF-8 输出，PowerShell 按控制台的 ANSI 代码页（中文系统是 936 / GBK）解码。管道里没有这个问题，只有写进控制台才会
- **解决**: 在按 UTF-8 渲染的终端里提交——Git Bash 里直接 `git commit -m "..."`；非要用 PowerShell，就先把控制台切到 UTF-8（`chcp 65001`）**再重开** PowerShell

## 历史教训

<!-- 从 tasks/ 复盘中提炼的稳定教训 -->
| 日期 | 问题 | 根因 | 修复方式 |
|---|---|---|---|
| | | | |
